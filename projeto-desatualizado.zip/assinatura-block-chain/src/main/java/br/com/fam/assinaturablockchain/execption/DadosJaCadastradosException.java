package br.com.fam.assinaturablockchain.execption;

public class DadosJaCadastradosException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public DadosJaCadastradosException(String msg) {
		super(msg);
	}
	
}
